run the "run" binary as described in the assignment 

./run Send \<interfaceName> \<DestHWAddy> \<message>

./run Recv \<interfaceName>

if the program needs to be recompiled for any reason, run the mk.sh which will remove the old binary and recompile under the same name