rm run
gcc 455_proj2.c -o run

